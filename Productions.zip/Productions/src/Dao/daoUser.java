/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Models.User;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author acer
 */
public class daoUser {
    
    public static void Ajouter(User u)
    {
        String requette = "insert into Users values(?,?)";
        try
        {
            DBConnect.ps = DBConnect.Connect().prepareStatement(requette);
            DBConnect.ps.setString(1, u.getNom());
            DBConnect.ps.setString(2, u.getPrenom());
            DBConnect.update();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    public static void Modifier(User u)
    {
        String requette = "update Users set Prenom=? where Nom=?";
        try
        {
            DBConnect.ps = DBConnect.Connect().prepareStatement(requette);
            DBConnect.ps.setString(1, u.getPrenom());
            DBConnect.ps.setString(2, u.getNom());
            DBConnect.update();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    public static void Supprimer(String nom)
    {
        String requette = "delete from users where Nom = ?";
        try
        {
            DBConnect.ps = DBConnect.Connect().prepareStatement(requette);
            DBConnect.ps.setString(1, nom);
            DBConnect.update();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    public static ResultSet SelectUser()
    {
        String requette = "select * from users order by nom";
        try
        {
            DBConnect.ps = DBConnect.Connect().prepareStatement(requette);
            return DBConnect.select();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return null;
        }
    }
    public static ResultSet SelectUserByNom(String nom)
    {
        String requette = "select * from users where nom=?";
        try
        {
            DBConnect.ps = DBConnect.Connect().prepareStatement(requette);
            DBConnect.ps.setString(1, nom);
            return DBConnect.select();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return null;
        }
    }
}
