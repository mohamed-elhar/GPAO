/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Dao.daoUser;
import Models.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author acer
 */
public class CUser {
    
    public static void ajouter(String nom,String prenom)
    {
        User user = new User(nom,prenom);
        daoUser.Ajouter(user);
    }
    public static void Modifier(String nom,String prenom)
    {
        User user = getUserByNom(nom);
        user.setPrenom(prenom);
        daoUser.Modifier(user);
    }
    public static void supprimer(String nom)
    {
        daoUser.Supprimer(nom);
    }
    public static void afficherTout(JTable table)
    {
        Vector<String> entete = new Vector<String>();
        entete.add("Nom");  entete.add("Prenom");
        Vector<String> ligne = null;
        Vector<Object> body = new Vector<Object>();
        try
        {
            ResultSet r = daoUser.SelectUser();
            while(r.next())
            {
                ligne = new Vector<String>();
                ligne.add(r.getString(1));
                ligne.add(r.getString(2));
                body.add(ligne);
            }
            table.setModel(new DefaultTableModel(body, entete));
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    public static User getUserByNom(String nom)
    {
        User user = null;
        try
        {
            ResultSet r = daoUser.SelectUserByNom(nom);
            if(r!=null)
            {
                r.next();
                user = new User(r.getString(1),r.getString(2));
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return user;
    }
}
