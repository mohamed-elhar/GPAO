/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Dao.daoUser;
import Models.User;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author acer
 */
public class CUser {
    
    public static void ajouter(User user)
    {
        daoUser.Ajouter(user);
    }
    public static void Modifier(User user)
    {
        daoUser.Modifier(user);
    }
    public static void supprimer(User user)
    {
        daoUser.Supprimer(user);
    }
    public static void afficherTout()
    {
        try
        {
            ResultSet r = daoUser.SelectUser();
            while(r.next())
            {
                System.out.println("Nom : "+r.getString(1)+" Prenom : "+r.getString(2));
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    public static void afficherbyNom(User user)
    {
        try
        {
            ResultSet r = daoUser.SelectUser(user);
            if(r!=null)
                System.out.println("Nom : "+r.getString(1)+" Prenom : "+r.getString(2));
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}
