/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author acer
 */
public class DBConnect {
    
    public static PreparedStatement ps=null;
    public static ResultSet rs=null;
    public static Connection conn=null;
    
    public static Connection Connect()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/Productions", "root", "1234");
        }
        catch(ClassNotFoundException e)
        {
            conn = null;
            e.printStackTrace();
        }
        catch(SQLException e)
        {
            conn = null;
            e.printStackTrace();
        }
        return conn;
    }
    
    public static int update()
    {
        int exec;
        try
        {
            exec = ps.executeUpdate();
        }
        catch(SQLException e)
        {
            exec = -1;
            e.printStackTrace();
        }
        return exec;
    }
    public static ResultSet select()
    {
        try
        {
            rs = ps.executeQuery();
        }
        catch(SQLException e)
        {
            rs = null;
            e.printStackTrace();
        }
        return rs;
    }
    
}
