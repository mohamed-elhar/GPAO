/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author acer
 */
public class User {
    private String Prenom;
    private String Nom;
    
    public User (){
        
    }
    public User (String Prenom,String Nom){
        this.Prenom = Prenom;
        this.Nom = Nom;
    }
    public User (String Nom){
        this.Nom = Nom;
    }
    public String getPrenom (){
    return Prenom; 
}
    public void setPrenom (String Prenom) {
        this.Prenom=Prenom;
    }
     public String getNom (){
    return Nom; 
}
    public void setNom (String Nom) {
        this.Nom=Nom;
    }
    
}
